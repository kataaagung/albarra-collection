<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.0
    </div>
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> <a href="/"><?php echo e($setting->nama_perusahaan); ?></a>.</strong> All rights
    reserved.
</footer><?php /**PATH E:\PROJECT\albarra-collection\resources\views/layouts/footer.blade.php ENDPATH**/ ?>